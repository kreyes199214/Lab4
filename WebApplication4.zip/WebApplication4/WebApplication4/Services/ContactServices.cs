﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using WebApplication4.Models;

namespace WebApplication4.Services
{
    public interface ContactServices

    {
        List<ManagerContacts> GetManagerContacts();
    //    Name GetManagerContact(string name);
   //     Pnumber GetManagerContact(string name);
//Email GetManagerContact(int name);
   //     void AddManagerContact(Contact contact);
     //   void UpdateManagerContact(Contact update);
    }
/*
    public class MockEmployeeService : IEmployeeService
    {
        private List<Employee> employees = new List<Employee>();

        public MockEmployeeService()
        {
            var john = new Employee
            {
                EmployeeId = 1,
                Name = "John",
                DateHired = new DateTime(2015, 1, 10)
            };
            var jane = new Employee
            {
                EmployeeId = 2,
                Name = "Jane",
                DateHired = new DateTime(2015, 2, 20),
                SupervisorId = 1,
                Supervisor = john
            };
            employees.Add(john);
            employees.Add(jane);
        }

        public List<Employee> GetEmployees()
        {
            return employees;
        }

        public Employee GetEmployee(int id)
        {
            return employees[id - 1];
        }

        public Employee GetEmployee(string username)
        {
            foreach (var employee in employees)
                if (employee.Username.ToUpper() == username.ToUpper())
                    return employee;
            return null;
        }

        public void AddEmployee(Employee employee)
        {
            employees.Add(employee);
        }

        public void UpdateEmployee(Employee update)
        {
            var employee = GetEmployee(update.EmployeeId);
            employee.Name = update.Name;
            employee.DateHired = update.DateHired;

    */
        }
   
