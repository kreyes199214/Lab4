﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;
using WebApplication4.Models;

namespace WebApplication3

{
    class AppDbContext : DbContext
    {
        private static readonly string connectionString;

        public DbSet<ManagerContacts> Contacts { get; set; }


        static AppDbContext()
        {
            IConfigurationRoot config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
            connectionString = config.GetConnectionString("Default");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //  optionsBuilder.UseLazyLoadingProxies().UseSqlServer(connectionString);
        }
    }
}
