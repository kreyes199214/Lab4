﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication4.Models
{
    public class ManagerContacts
    {
        
  //  [Table("Contact")]

        
            public string Name { get; set; }
            public int Pnumber { get; set; }
            public int EMail { get; set; }

        }

    }
